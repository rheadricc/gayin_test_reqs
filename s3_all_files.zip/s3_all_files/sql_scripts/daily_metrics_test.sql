WITH
BaseData as (
SELECT
    status,
    subscription_plan_id,
    TIMEZONE('PST',valid_until::timestamp) valid_until,
    user_id,
    email,
    TIMEZONE('PST',registered_at::timestamp) registered_at,
    TIMEZONE('PST',created_at::timestamp) created_at,
    TIMEZONE('PST',grace_until::timestamp) grace_until,
    TIMEZONE('PST',NVL(free_trial_start_date,created_at)::timestamp) free_trial_start_date,
    TIMEZONE('PST',NVL(free_trial_end_date,created_at)::timestamp) free_trial_end_date,
    NVL(applied_promotions,'[]') applied_promotions
FROM "gain-dwh-prod"."int_transaction"."elastic_user"
    where date(created_at) <= '2025-02-03'
    --and free_trial_start_date = ''
    --order by 1
),
UpdateData as (
    SELECT
        *
    FROM
        (
        SELECT
            status,
            subscription_plan_id,
            valid_until,
            user_id,
            email,
            registered_at,
            created_at,
            grace_until,
            free_trial_start_date,
            free_trial_end_date,
            applied_promotions,
            ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY created_at DESC) AS rownum
        FROM "gain-dwh-prod"."int_transaction"."subs_payment"
            WHERE DATE(created_At) > '2025-02-03' and DATE(created_At) <= '{{target_date}}'
        ) WHERE rownum = 1
),
ReportData as (
SELECT
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.status
        WHEN  ud.created_at is null THEN bd.status
        ELSE ud.status
    END status,
   NVL(bd.subscription_plan_id,ud.subscription_plan_id) subscription_plan_id,
   CASE
        WHEN bd.created_at > ud.created_at THEN bd.valid_until
        WHEN  ud.created_at is null THEN bd.valid_until
        ELSE ud.valid_until
    END valid_until,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.user_id
        WHEN  ud.created_at is null THEN bd.user_id
        ELSE ud.user_id
    END user_id,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.email
        WHEN  ud.created_at is null THEN bd.email
        ELSE ud.email
    END email,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.registered_at
        WHEN  ud.created_at is null THEN bd.registered_at
        ELSE ud.registered_at
    END registered_at,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.created_at
        WHEN  ud.created_at is null THEN bd.created_at
        ELSE ud.created_at
    END created_at,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.grace_until
        WHEN  ud.created_at is null THEN bd.grace_until
        ELSE ud.grace_until
    END grace_until,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.free_trial_start_date
        WHEN  ud.created_at is null THEN bd.free_trial_start_date
        ELSE ud.free_trial_start_date
    END free_trial_start_date,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.free_trial_end_date
        WHEN  ud.created_at is null THEN bd.free_trial_end_date
        ELSE ud.free_trial_end_date
    END free_trial_end_date,
    CASE
        WHEN bd.created_at > ud.created_at THEN bd.applied_promotions
        WHEN  ud.created_at is null THEN bd.applied_promotions
        ELSE ud.applied_promotions
    END applied_promotions
FROM BaseData bd
    FULL JOIN UpdateData ud ON bd.user_id = ud.user_id
),
NewUsers as (
    ---Yanlış mantık hatası signup düşmüyor bize
    SELECT
        '{{target_date}}' AS Date,
        0 /*count(DISTINCT user_id)*/ NewUserCount
    --FROM BaseData
    --where DATE(registered_At) = '{{target_date}}'
   -- and DATE(created_At) = '{{target_date}}'
),
NewSales as
(
    SELECT
        '{{target_date}}' AS Date,
        count(DISTINCT user_id) NewSalesCount
    FROM ReportData
    where DATE(created_at) = '{{target_date}}'
    --and DATE(registered_At) = '{{target_date}}'
    and status = 'ACTIVE'
    and subscription_plan_id is not null
),
CanceledUsers as
(
    SELECT
        '{{target_date}}' AS Date,
        count(DISTINCT user_id) CanceledCount
    FROM ReportData
        where DATE(created_at) = '{{target_date}}'
            and status IN ('EXPIRED','ON_HOLD')
),
TotalPaidUsers as
(
    SELECT
        '{{target_date}}' AS Date,
        count(DISTINCT user_id)  TotalPaidUserCount
    FROM ReportData
    where DATE(created_at) <= '{{target_date}}'
    --and DATE(valid_until) >= '{{target_date}}'
    and status IN ('ACTIVE','CANCELED')
    and subscription_plan_id is not null
),
GraceUsers as
(
    SELECT
        '{{target_date}}' AS Date,
        count(DISTINCT user_id) GraceUserCount
    FROM ReportData
    where DATE(grace_until) >= '{{target_date}}'
        and status = 'IN_GRACE'
        and subscription_plan_id is not null
),
SevenDaysTrialUsage as
(
    select
        '{{target_date}}' AS Date,
        COUNT(DISTINCT user_id) SevenDaysTrialUsage
    FROM ReportData
        where date(created_at) = '{{target_date}}'
            and date(free_trial_start_date) = '{{target_date}}'
            and DATEDIFF(days,free_trial_start_date::timestamp,valid_until::timestamp) = 7
            and status = 'ACTIVE'
),
SevenDaysTrialContinue as
(
    SELECT
        '{{target_date}}' as Date,
        COUNT(DISTINCT user_id) SevenDaysTrialContinue
    FROM ReportData
        where '{{target_date}}' <= valid_until
            and '{{target_date}}' >= date(free_trial_start_date) and '{{target_date}}' <= date(free_trial_end_date)
            and DATEDIFF(days,free_trial_start_date::timestamp,valid_until::timestamp) = 7
            --and status = 'ACTIVE'
),
SevenDaysPromoUsage as
(
    SELECT
        '{{target_date}}' as DATE,
        COUNT(DISTINCT user_id) SevenDaysPromoUsage
    FROM ReportData
where status = 'ACTIVE'
    and DATE(JSON_EXTRACT_PATH_TEXT(JSON_EXTRACT_ARRAY_ELEMENT_TEXT(applied_promotions,0),'applyDate')) = '{{target_date}}'
    and JSON_EXTRACT_PATH_TEXT(JSON_EXTRACT_ARRAY_ELEMENT_TEXT(JSON_EXTRACT_PATH_TEXT( JSON_EXTRACT_ARRAY_ELEMENT_TEXT(applied_promotions,0),'benefits'),0),'freePremiumByDay') = 7
),
SevenDaysPromoContinue as
(
    SELECT
        '{{target_date}}' as Date,
        COUNT(DISTINCT user_id) SevenDaysPromoContinue
    FROM ReportData
where --status = 'ACTIVE' and
    DATEADD(day,7,DATE(JSON_EXTRACT_PATH_TEXT(JSON_EXTRACT_ARRAY_ELEMENT_TEXT(applied_promotions,0),'applyDate'))) >= '{{target_date}}'
    and JSON_EXTRACT_PATH_TEXT(JSON_EXTRACT_ARRAY_ELEMENT_TEXT(JSON_EXTRACT_PATH_TEXT(JSON_EXTRACT_ARRAY_ELEMENT_TEXT(applied_promotions,0),'benefits'),0),'freePremiumByDay') = 7
),
AbonelikSatinAlan as
(
    SELECT
        '{{target_date}}' as Date,
        COUNT(DISTINCT user_id) AbonelikSatinAlan
    FROM ReportData
        where date(created_at) >= CURRENT_DATE - 8 and DATE(created_at) <= '{{target_date}}'
        and status = 'ACTIVE'
),
TotalPromoUsers as
(
    SELECT
        '{{target_date}}' AS Date,
        count(DISTINCT user_id)  TotalPromoUsers
    FROM ReportData
    where DATE(created_at) <= '{{target_date}}'
    --and DATE(valid_until) >= '{{target_date}}'
    and status IN ('ACTIVE','CANCELED')
    and subscription_plan_id is not null
    and json_extract_path_text( json_extract_array_element_text(applied_promotions, 0), 'promotionId' ) IS NOT NULL
),
PvtData as
(
SELECT
    date,
    'Yeni Kayıt Yapan' AS metric,
    0 as rownum,
    newusercount AS value
FROM NewUsers
    UNION ALL
SELECT
    date,
    'Yeni Abonelik Satın Alan' AS metric,
    3 as rownum,
    newsalescount AS value
FROM NewSales
    UNION ALL
SELECT
    date,
    'İptal Edilen Abonelik' AS metric,
    4 as rownum,
    canceledcount AS value
FROM CanceledUsers
    UNION ALL
SELECT
    date,
    'Toplam Ücretli Abonelik' AS metric,
    1 as rownum,
    totalpaidusercount AS value
FROM TotalPaidUsers
    UNION ALL
SELECT
    date,
    'Grace Period Sürecindeki Kullanıcılar' AS metric,
    5 as rownum,
    graceusercount AS value
FROM GraceUsers
    UNION ALL
SELECT
    date,
    '7 Günlük Ücretsiz Deneme Kullanımı' AS metric,
    6 as rownum,
    SevenDaysTrialUsage AS value
FROM SevenDaysTrialUsage
    UNION ALL
SELECT
    date,
    '7 Günlük Promosyon Kullanımı' AS metric,
    7 as rownum,
    SevenDaysPromoUsage AS value
FROM SevenDaysPromoUsage
    UNION ALL
SELECT
    date,
    '7 Günlük Ücretsiz Deneme Devam Edenler' AS metric,
    8 as rownum,
    SevenDaysTrialContinue AS value
FROM SevenDaysTrialContinue
    UNION ALL
SELECT
    date,
    '7 Günlük Promosyon Devam Eden' AS metric,
    9 as rownum,
    SevenDaysPromoContinue AS value
FROM SevenDaysPromoContinue
    UNION ALL
SELECT
    date,
    'Son 1 Haftada Abonelik Satın Alan' AS metric,
    10 as rownum,
    AbonelikSatinAlan AS value
FROM AbonelikSatinAlan
    UNION ALL
SELECT
    date,
    'Promosyon Kullanmış Ücretli Abone' AS metric,
    2 as rownum,
    TotalPromoUsers AS value
FROM TotalPromoUsers
)
    SELECT * FROM pvtdata
    where rownum != 0 order by rownum